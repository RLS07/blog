<?php

include("sessioncheck.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="../css/bootstrap.css">
</head>
<body>
    <header class="container my-5">
    <?php

echo "<button type='button' class='btn btn-danger'><a href=logout.php class='text-light' style='text-decoration:none;'>LOGOUT</a></button>";

echo '<br>';
echo "<h1>Welcome ".$_SESSION['username']."</h1>";
echo '<br>';

echo "<a href='editdeleteuser.php'>Edit or Delete users</a>";

echo 'The date and time rn is: '.$_SESSION['accesstime'];
echo '<br>';
include('../login_project/connections.php');
?>
    
    <footer>
  <p>Copyright &copy; Devpractical.com</p>
</footer>

    
</body>
</html>