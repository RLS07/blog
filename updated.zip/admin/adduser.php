<?php
include '../login_project/connections.php';
if(isset($_POST['submit'])){
    $username=$_POST['username'];
    $password=$_POST['password'];
    $email=$_POST['email'];

    $sql="insert into `users` (username,password,email)
    values('$username',md5('$password'),'$email')";
    $result=mysqli_query($conn,$sql);
    if($result){
        echo'DATE INSERTED SUCCESS';

    }else{
        die(mysqli_error($conn)); 
    }
}




?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add new user</title>
    <link rel="stylesheet" href="../css/bootstrap.css">
</head>
<body>
    <div class="container my-5">
    <form method="Post">

    <div class="mb-3">
    <label class="form-label">Username</label>
    <input type="text" class="form-control" name="username" autocomplete="off" placeholder="Enter username">
    </div>

    <div class="mb-3">
    <label class="form-label">Password</label>
    <input type="text" class="form-control" name="password" autocomplete="off" placeholder="Enter password">
    </div>

    <div class="mb-3">
    <label class="form-label">email</label>
    <input type="email" class="form-control" name="email" autocomplete="off" placeholder="Enter email">
    </div>

  <button type="submit" class="btn btn-primary my-3" name="submit">Submit</button>
</form>
    </div>
</body>
</html>