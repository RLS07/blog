<?php

include("sessioncheck.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Delete User</title>
    <link rel="stylesheet" href="../css/bootstrap.css">
</head>
<body>
    <header class="container my-5">
    <?php

echo "<button type='button' class='btn btn-danger'><a href=logout.php class='text-light' style='text-decoration:none;'>LOGOUT</a></button>";

echo '<br>';
echo "<h1>Welcome ".$_SESSION['username']."</h1>";
echo '<br>';
echo 'The date and time rn is: '.$_SESSION['accesstime'];
echo '<br>';
include('../login_project/connections.php');
?>
    <button type="button" class="btn btn-primary my-3"><a href="../login_project/connection_register_form.php" class="text-light" style="text-decoration:none; text-align:center;">Add user</a></button>
    
    </header>
    <main class="row " style="margin:0 50px;">
    <div class="col-xxl-12">
    <table class="table table-hover">
  <thead>
    <tr>
      <th scope="col">ID</th>
      <th scope="col">Username</th>
      <th scope="col">Passoword</th>
      <th scope="col">Email</th>
      <th scope="col">Role</th>
      <th scope="col">Status</th>
      <th scope="col">Operations</th>
    </tr>
  </thead>
  <tbody>
    <?php
    $sql="Select * from users";
    $result=mysqli_query($conn,$sql);
    if($result){
        
        while($row=mysqli_fetch_assoc($result)){
            $id=$row['id'];
            $username=$row['username'];
            $password=$row['password'];
            $email=$row['email'];
            $role=$row['role'];
            $status=$row['status'];
            echo '<tr>
            <th scope="row">'.$id.'</th>
            <td>'.$username.'</td>
            <td>'.$password.'</td>
            <td>'.$email.'</td>
            <td>'.$role.'</td>
            <td>'.$status.'</td>
            <td><button class="btn btn-primary"><a href="update.php?updateid='.$id.'"update"&&id=$id class="text-light" style="text-decoration:none;">Update</a></button>
            <button class="btn btn-danger"><a href="delete.php?deleteid='.$id.'" class="text-light" style="text-decoration:none;">Delete</a></button><td>
          </tr>';
        }
    }
    ?>

  </tbody>
</table>
    </div>
    <div class="col-xxl-6">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Beatae quae ad unde error aspernatur ipsum sit, exercitationem odio reiciendis eveniet consequatur animi provident nihil consequuntur est dolorum quis ullam cum.</div>

    </main>
    <footer class="container my-5">
  <p>Copyright &copy; rojanblogs.com</p>
</footer>
    
</body>
</html>