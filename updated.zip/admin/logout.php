<?php
include("sessioncheck.php");


session_destroy();
header("Location:../login_project/login.php")
?>