
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <?php
    session_start();
        if(isset($_POST["submit"])){
            $user=$_POST["username"];
            $pass=$_POST["password"];
            $remme=$_POST["remme"];
            
            $sql="SELECT * from users where username='$user' and password=md5('$pass') and status=1";
            //connectin to db
            include("connections.php");
            //executing query
            $qry=mysqli_query($conn,$sql) or die(mysqli_error($conn)); //don't we have to call the variable

            $count=mysqli_num_rows($qry);

            if($count==1){
                if(!empty($remme)){
                //setting username and password cookie for 15 days
                setcookie("username","$user",time()+60*60*24*15,"/");
                setcookie("password","$pass",time()+60*60*24*15,"/");
                }
                //register the session
                $_SESSION["username"]=$user;
                $_SESSION["accesstime"]=date('Y-m-d-h-i-s-a');
                //redirect if user is valid
                header("Location:../admin/dashboard.php");
            }else{
                echo"Login Failed";
            }
        }
    ?>
    <form action="" method="post" name="login" enctype="multipart/form-data">
        <fieldset> 
            <legend>Login</legend>
        
        <input type="text" name="username" placeholder="Username" value="<?php if(isset($_COOKIE['username'])){echo $_COOKIE['username'];}else{echo'';}?>">
        <br>
        <input type="password" name="password" placeholder="password" value="<?php if(isset($_COOKIE['password'])){echo $_COOKIE['password'];}else{echo'';}?>">
        <br>
        <input type="submit" value="Login" name="submit">
        <input type="checkbox" name="remme" value="rem" id="">Remember Me<br>
        </fieldset>
        <p>Create a new ACCOUNT!<a href="connection_register_form.php">Register Now!</a></p>

    </form>

    
</body>
</html>