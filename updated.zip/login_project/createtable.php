<?php
    $sql="
    CREATE TABLE if not exists users(
        id int primary key auto_increment,
        username VARCHAR(50) UNIQUE not null,
        password VARCHAR(50) UNIQUE not null,
        email VARCHAR(50) UNIQUE,
        role VARCHAR(5) not null default 'user',
        status tinyint(1) not null default'0'
        
    )
    ";

    //connecting to db
    include_once("connections.php");
    //executing query
    $qry=mysqli_query($conn,$sql) or die(mysqli_error($conn));
    if($qry){
        echo "users Table created Successfully";
    }
?>