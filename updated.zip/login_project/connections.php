<?php
$host="localhost";
$dbuser="root";
$dbpass="";
$dbname="student";
//baking connections
$conn=mysqli_connect($host,$dbuser,$dbpass,$dbname) or die ("Unable to connect to database");
?>