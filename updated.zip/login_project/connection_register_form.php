<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    if(isset($_POST['submit'])){  //is submit existed or not ? CHECK HERE
            //getting user info
            $user=$_POST["username"];
            $pass=md5($_POST["password"]);
            $email=$_POST["email"];

            $sql="INSERT INTO users(username,password,email)VALUES('$user','$pass','$email')";

            //making connection
            include_once("connections.php");
            //executing query

            $qry=mysqli_query($conn,$sql) or die(mysqli_error($conn));
            if($qry){
                echo "Data Inseted Successfully.";
            }


    }
    ?>
<form action="" method="post" name="login" enctype="multipart/form-data">
        <fieldset> 
            <legend>User Registration</legend>
        
        <input type="text" name="username" placeholder="Username" >
        <br>
        <input type="password" name="password" placeholder="password">
        <br>
        <input type="email" name="email" placeholder="example@domain.com">
        <br>
        <input type="submit" value="Register" name="submit">
        </fieldset>
    </form>
    <p>Already Registered. <a href="login.php">LOGIN HERE!</a></p>
</body>
</html>